# Libarclite-Files

Xcode 14.3 and 14.3.1 has build issues with some Cocoa pods because of the absence of '.a' files in its XcodeDefaults toolchain contents.
Here are all the missing files in Xcode 14.3.

You can download and paste it into this path:
> /Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/lib/arc/

* Note: Create a folder called 'arc' in lib folder if it doesn't exist.
